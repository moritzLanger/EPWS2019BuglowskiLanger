﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Zufall : MonoBehaviour
{   GameObject game;
    GamingScript gs;
    private static int anzahl;
    private int[] zufallsarray;
    private System.Random random = new System.Random();
    private GameObject temp, cube;
    private Text texte;
    private Triggerplate triggerplate;
    
    // Start is called before the first frame update
    void Start()
    {
        anzahl = GameObject.Find("GamingObj").GetComponentInChildren<GamingScript>().anzPlates;
        zufallsarray = new int[anzahl];

        ZufallsgeneratorMethode();
        for (int i = 1; i < anzahl+1; i++)
        {
            temp = GameObject.Find("Numberplate " + i);
            triggerplate = temp.GetComponent<Triggerplate>();
            triggerplate.setUeber(zufallsarray[i-1]);
            texte = temp.GetComponentInChildren<Text>();
            texte.text = zufallsarray[i-1].ToString();
        }
        CubeErzeuger();
        zusatzBloeckeMethode();
    }
    public void ZufallsgeneratorMethode()
    {
        int i = 0;
        while (i < anzahl)
        {
            bool pruefung = true;
            int temp2 = random.Next(0, 10);
            for (int j = 0; j < anzahl; j++)
            {
                if (zufallsarray[j] == temp2)
                {
                    pruefung = false;
                }
            }
            if (pruefung)
            {
                zufallsarray[i] = temp2;
                i++;
            }
        }
    }

    private void CubeErzeuger()
    {
        int wertigkeit, count;
        for (int i = 0; i < anzahl; i++)
        {
            count = 0;
            while (count < zufallsarray[i])
            {
            print(count);
            wertigkeit = random.Next(0, 5);

                if (count + wertigkeit <= zufallsarray[i])
                {
                    count += wertigkeit;
                    switchMethode(wertigkeit);
                    
                }
            }
        }

    }

    private void zusatzBloeckeMethode()
    {
        int zusatzbloecke = random.Next(0, 3);
        for (int i = 0; i < zusatzbloecke; i++)
        {
            switchMethode(random.Next(0, 5));
        }
    }

    private void switchMethode(int wertigkeit)
    {
        switch (wertigkeit)
        {
            case 1:
                cube = CubeErsteller();
                cube.GetComponent<Zahl>().setWertigkeit(wertigkeit);
                cube.transform.localScale += new Vector3(1, 1, 1);

                break;
            case 2:
                cube = CubeErsteller();
                cube.GetComponent<Zahl>().setWertigkeit(wertigkeit);
                cube.transform.localScale += new Vector3(3, 1, 1);
                break;
            case 3:
                cube = CubeErsteller();
                cube.GetComponent<Zahl>().setWertigkeit(wertigkeit);
                cube.transform.localScale += new Vector3(1, 1, 5);
                break;
            case 4:
                cube = CubeErsteller();
                cube.GetComponent<Zahl>().setWertigkeit(wertigkeit);
                cube.transform.localScale += new Vector3(3, 1, 3);
                break;
            default:
                print("Default case");
                break;
        }
    }
    public GameObject CubeErsteller()
    {
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        Vector3 zufallposi = new Vector3(random.Next(-22, 22), 2, random.Next(2, 45));
        cube.transform.position = zufallposi;
        cube.AddComponent<Movement>();
        cube.AddComponent<Rigidbody>();
        cube.GetComponent<Rigidbody>().useGravity = true;
        //cube.GetComponent<Rigidbody>().freezeRotation = true;
        cube.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotation;
        cube.AddComponent<Zahl>();
        return cube;
    }
}
