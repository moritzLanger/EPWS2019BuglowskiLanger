﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class Zufallsgenerator : MonoBehaviour
{
    private static int anzahl = 6;
    private int [] zufallsarray = new int[anzahl];
    private Vector3[] positionsarray = new Vector3[7];
    private  System.Random random = new System.Random();
    private GameObject temp;
    private Text texte;

    // Start is called before the first frame update
    void Start()
    {
        ZufallsgeneratorMethode();
        for(int i = 1; i < 7; i++)
        {
        temp = GameObject.Find("Cube " + i );
        positionsarray[(i - 1)] = temp.transform.position;
        texte = temp.GetComponentInChildren<Text>();
        texte.text =  zufallsarray[i-1].ToString();
        }
        Positionszufall();
    }
    

    public void ZufallsgeneratorMethode()
    {
        int i = 0;
        while(i < anzahl){    
            bool pruefung = true;
            int temp2 = random.Next(0, 10);
            for(int j = 0; j <anzahl; j++){
                if (zufallsarray[j] == temp2){
                    pruefung = false;
                }
            }
            if(pruefung){
            zufallsarray[i]  = temp2;
            i++;
            }
        }

        
        Array.Sort(zufallsarray);
    }
    public void Positionszufall()
    {
        for (int i = 1; i < 7; i++)
        {

            temp = GameObject.Find("Cube " + i);
            RandomPos(temp, i);
        }
    }

    private void RandomPos(GameObject Pos,int i)
    {
        try
        {

            int zufallsnummer = random.Next(0, 6);
            Vector3 leer = new Vector3(0, 0, 0);
            if (positionsarray[zufallsnummer].Equals(leer))
            {
                RandomPos(Pos, i);
            }
            else
            {
                if ((i - 1) == zufallsnummer)
                {

                    RandomPos(Pos, i);
                }
                else
                {
                    Pos.transform.position = positionsarray[zufallsnummer];
                    positionsarray[zufallsnummer] = leer;
                }
            }



        }
        catch (StackOverflowException e)
        {
            print("exeption gefangen, aber random funktioniert");
        }

            /*
            Vector3[] positionen = new Vector3[anzahl];
            for (int i = 1; i < 7; i++)
            {
                temp = GameObject.Find("Cube " + i);
                i--;
                positionen[i] = temp.transform.position;    
                print(temp.transform.position);
                print(positionen[i]);
                i++;
            }
            for(int j = 1; j < 7; j++)
            {
                temp = GameObject.Find("Cube " + j);
                temp.transform.position = positionen[ZufallfuerPosi(j)];
            }
        }*/
        }
    /*
    public int ZufallfuerPosi(int i)
    {
        int posiZufall = random.Next(0, 7);
        if(posiZufall == i)
        {
            
            return ZufallfuerPosi(i);
        }
        return posiZufall;
    }*/
    }



