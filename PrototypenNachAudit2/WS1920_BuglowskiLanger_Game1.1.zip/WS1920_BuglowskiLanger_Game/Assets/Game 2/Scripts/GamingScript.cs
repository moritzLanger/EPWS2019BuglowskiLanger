﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GamingScript : MonoBehaviour
{
    private System.Random random = new System.Random();
    public int anzPlates = 2;
    public int count = 0;
    public GameObject complete,exitBtn,ctrTrigger;
    // Start is called before the first frame update
    void Start()
    {
        exitBtn.SetActive(true);
    }

    private void Update()
    {
        if(SceneManager.GetActiveScene().buildIndex == 2)
        {
            CheckPlates();
        }
        else if(SceneManager.GetActiveScene().buildIndex == 3)
        {
            if (ctrTrigger.GetComponent<controlscript>().allerichtig)
            {
                complete.SetActive(true);
            }
        }
    }

    // Update is called once per frame
    private  void CheckPlates()
    {
        count = 0;
        for (int i = 1; i < anzPlates + 1; i++)
        {
            if (GameObject.Find("Numberplate " + i).GetComponentInChildren<Triggerplate>().ausgefuellt)
            {
                count++;
            }
        }
        if (count == anzPlates)
        {
            complete.SetActive(true);
            
            //Application.Quit();
        }

    }

    public void SuccessBtnFunk()
    {
        //int randomScene = random.Next(0, 3);
        SceneManager.LoadScene(2);
    }

    public void ExitBtnFunk()
    {
        SceneManager.LoadScene(0);
    }
}
