﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Triggerscript : MonoBehaviour
{
    public int count;
    public GameObject control;
    void Start()
    {
        control = GameObject.Find("Triggers");
    }

    private void OnTriggerEnter(Collider other)
    {

        string[] cubename = other.gameObject.name.Split(new char[] { ' ' });

        string[] triggername = this.gameObject.name.Split(new char[] { ' ' });

        if (cubename[1].Equals(triggername[1]))
        {
            count++;
            control.GetComponent<controlscript>().test();
        }
        

    }
    private void OnTriggerExit(Collider other)
    {
        string[] cubename = other.gameObject.name.Split(new char[] { ' ' });

        string[] triggername = this.gameObject.name.Split(new char[] { ' ' });

        if (cubename[1].Equals(triggername[1]))
        {
            count--;
            control.GetComponent<controlscript>().negativtest();
        }
        
    }
}
