﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{
    private System.Random random = new System.Random();
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnClickSpielAuswBtn()
    {
        SceneManager.LoadScene(1);
    }

    public void OnClickGame1Btn()
    {
        //SceneManager.LoadScene(2);
    }

    public void OnClickGame2Btn()
    {
        //SceneManager.LoadScene(3);
        SceneManager.LoadScene(2);
    }

    public void OnClickGame3Btn()
    {
        //SceneManager.LoadScene(4);
        SceneManager.LoadScene(3);
    }

    public void OnClickRndmBtn()
    {
        int randomScene = random.Next(1, 4);
        SceneManager.LoadScene(randomScene);
    }
}
