﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerTube : MonoBehaviour
{
    public GameObject tube;
    public Material correctMat,falseMat,resetMat;
    GameObject cube,tubeTr;
    ZahlSpiel1 cs;
    public int tubeZahl;
    public Renderer farbe;
    public bool prueft = false;
    //int i = 0;

    private void OnTriggerEnter(Collider other)
    {
        cube = other.gameObject;
        cs = cube.GetComponent<ZahlSpiel1>();
        tubeTr = this.gameObject;
        //tube = GameObject.Find("TubeEP");
        farbe = tube.GetComponent<Renderer>();






    }

    
    private void OnTriggerStay(Collider other)
    {

        if (cs.summe != tubeZahl && !Input.anyKey)
        {
            farbe.material = falseMat;
            other.GetComponent<Rigidbody>().useGravity = false;
            prueft = true;
            other.transform.position = Vector3.MoveTowards(other.transform.position, new Vector3(tube.transform.position.x, tube.transform.position.y, other.transform.position.z), Time.deltaTime * 50f);
            other.transform.position = Vector3.MoveTowards(other.transform.position, new Vector3(tube.transform.position.x, tube.transform.position.y, 13f), Time.deltaTime * 15);
            
            
            //print(i++);
            
            //cube.transform.position = cs.startPosi;
            // farbe.material = resetMat;

        }
        else if (!Input.anyKey ) {
            //ansonsten TOUCH COUNT

                
                farbe.material = correctMat;
                other.GetComponent<Rigidbody>().useGravity = false;
                other.transform.position = Vector3.MoveTowards(other.transform.position, new Vector3(tube.transform.position.x, tube.transform.position.y, other.transform.position.z), Time.deltaTime * 50f);
                other.transform.position = Vector3.MoveTowards(other.transform.position, new Vector3(tube.transform.position.x, tube.transform.position.y, 13f), Time.deltaTime * 15);
                prueft = true;
        }          
            
       }


    public void settubeZahl(int neu)
    {
        tubeZahl = neu;
    }
    private void OnTriggerExit(Collider other)
    {
        prueft = false;
        farbe.material = resetMat;
        /*
        if (cs.summe == tubeZahl)
        {
            Destroy(other.gameObject);

        }*/
        //farbe.material = resetMat; 
        //i = 0;
        
    }

   
}