﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GamingScript : MonoBehaviour
{
    private System.Random random = new System.Random();
    public int anzPlates = 2;
    private int anzCubes = 4;
    private int anzTubes = 2;
    public int count = 0;
    public int cubes = 0;
    public GameObject complete,exitBtn,ctrTrigger;
    // Start is called before the first frame update
    void Start()
    {
        exitBtn.SetActive(true);
    }

    private void Update()
    {
        if (SceneManager.GetActiveScene().buildIndex == 2)
        {
            CheckDestrCubes();
        }
        else if(SceneManager.GetActiveScene().buildIndex == 3)
        {
            CheckPlates();
        }
        else if(SceneManager.GetActiveScene().buildIndex == 4)
        {
            if (ctrTrigger.GetComponent<controlscript>().allerichtig)
            {
                complete.SetActive(true);
            }
        }
    }

    // Update is called once per frame
    private  void CheckPlates()
    {
        count = 0;
        for (int i = 1; i < anzPlates + 1; i++)
        {
            if (GameObject.Find("Numberplate " + i).GetComponentInChildren<Triggerplate>().ausgefuellt)
            {
                count++;
            }
        }
        if (count == anzPlates)
        {
            complete.SetActive(true);
            
            //Application.Quit();
        }

    }

    private void CheckDestrCubes()
    {
        cubes = 0;
        for (int i = 1; i < anzTubes + 1; i++)
        {
            cubes += GameObject.Find("Tube " + i).GetComponentInChildren<DestroyCube>().destroyedCubes;
            
        }
        if(cubes == anzCubes)
        {
            complete.SetActive(true);
        }
    }

    public void SuccessBtnFunk()
    {
        int randomScene = random.Next(2, 5);
        SceneManager.LoadScene(randomScene);
    }

    public void ExitBtnFunk()
    {
        SceneManager.LoadScene(0);
    }
}
