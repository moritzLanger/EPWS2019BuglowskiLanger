﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
/*
public class Position
{
    public int id { get; set; }
    public float position { get; set; }
    public bool besetzt { get; set; }

}*/
public class Zufallsrechnungen : ZufallOberklasse
{

    private static int anzahl = 3;
    private int[] zufallsarray = new int[anzahl];
    private Vector3[] positionsarray = new Vector3[5];
    private List<int> checkListe = new List<int>();
   // private List<Position> posListe = new List<Position>();
    // Start is called before the first frame update
    void Start()
    {
        ZufallsgeneratorMethode(zufallsarray, anzahl);
        for(int i = 1; i < anzahl; i++)
        {
            temp = GameObject.Find("Tube " + i);
            temp.GetComponentInChildren<TriggerTube>().settubeZahl(zufallsarray[i - 1]);
            texte = temp.GetComponentInChildren<Text>(); 
            texte.text = zufallsarray[i - 1].ToString();
        }
        CubeRechnungen();
        PositionsZufall();
    }

    private void PositionsZufall()
    {
        for (int i = 1; i < 4 ; i++)
        {
            
            temp = GameObject.Find("Rechencube " + i);
            RandomPos(temp);
        }
      

    }
    private void RandomPos(GameObject Pos)
    {
        int zufallsnummer = random.Next(0, 4);
        Vector3 leer = new Vector3 (0, 0, 0);
        if (positionsarray[zufallsnummer].Equals(leer))
        {
            RandomPos(Pos);
        }
        else { 
            Pos.transform.position = positionsarray[zufallsnummer];
            positionsarray[zufallsnummer] = leer;
        }
    /*  Position tempPos;
       
        int randomPos = random.Next(1, 4);
        print(randomPos);
        tempPos = posListe.Find(x => x.id == randomPos);
        print(tempPos.position);
        if (!tempPos.besetzt)
        {
            temp.transform.position = new Vector3(tempPos.position, temp.transform.position.y, temp.transform.position.z);
            tempPos.besetzt = true;
            
        }
        else
        {
            RandomPos(Pos);
        }  
    */
    }
   

    

    private void CubeRechnungen()
    {
        int temp2;
        if (zufallsarray[0] <=3)
        {
            temp2 = (-1) + zufallsarray[0];
        }else if (zufallsarray[1] == 2)
        {
            temp2 = 5 - zufallsarray[1];

        }else
        {
            temp2 = random.Next(1, 4);
        }

        for (int i = 1; i < 5; i++)
        {
            temp = GameObject.Find("Rechencube " + i);
            positionsarray[(i - 1)] = temp.transform.position;
            //posListe.Add(new Position() {id = i, position = temp.transform.position.x, besetzt = false });
            if (i <= temp2)
            {
                Zahlenzuweiszung(temp, 0);
            }
            else
            {
                Zahlenzuweiszung(temp, 1);
            }
        }
    }

    private void Zahlenzuweiszung(GameObject cube, int z)
    {
        int z1 = random.Next(0, zufallsarray[z]);
        if (checkListe.Contains(z1)) {
            Zahlenzuweiszung(cube, z);
        }
        else {
            int z2 = zufallsarray[z] - z1;
            ZahlSpiel1 zahl = cube.GetComponentInChildren<ZahlSpiel1>();
            zahl.zahl1 = z1;
            zahl.zahl2 = z2;
            checkListe.Add(z1);
        }
    }



}
