﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Movement : MonoBehaviour
{

    Transform movingObj;
   

    void Update()
    {
        //Unsichtbare Wände
        if (movingObj != null && movingObj.transform.position.y < 1.25)//Boden
        {
            movingObj.position = new Vector3(movingObj.position.x, 1.25f, movingObj.position.z);
        }
        else if (movingObj != null && movingObj.transform.position.x < -22.48654 && movingObj.transform.position.z > 47.5)//Links Hinten
        {
            movingObj.position = new Vector3(-22.48654f, movingObj.position.y, 47.5f);
        }
        else if (movingObj != null && movingObj.transform.position.x < -22.48654 && movingObj.transform.position.z < 1.28891f)//Links Vorne
        {
            movingObj.position = new Vector3(-22.48654f, movingObj.position.y, 1.28891f);
        }else if (movingObj != null && movingObj.transform.position.x > 22.48654 && movingObj.transform.position.z > 47.5)//Rechts Hinten
        {
            movingObj.position = new Vector3(22.48654f, movingObj.position.y, 47.5f);
        }
        else if (movingObj != null && movingObj.transform.position.x > 22.48654 && movingObj.transform.position.z < 1.28891f)//Rechts Vorne
        {
            movingObj.position = new Vector3(22.48654f, movingObj.position.y, 1.28891f);
        }
        else if (movingObj != null && movingObj.transform.position.z > 47.5)//Hinten
        {
            movingObj.position = new Vector3(movingObj.position.x, movingObj.position.y, 47.5f);
        }
        else if (movingObj != null && movingObj.transform.position.z < 1.28891f)//Vorne
        {
            movingObj.position = new Vector3(movingObj.position.x, movingObj.position.y, 1.28891f);
        }
        else if (movingObj != null && movingObj.transform.position.y > 2)//Höhe
        {
            movingObj.position = new Vector3(movingObj.position.x,2f ,movingObj.position.z);
        }else if (movingObj != null && movingObj.transform.position.x < -22.48654)//Links
        {
            movingObj.position = new Vector3(-22.48654f, movingObj.position.y, movingObj.position.z);
        }
        else if (movingObj != null && movingObj.transform.position.x > 22.48654)//Links
        {
            movingObj.position = new Vector3(22.48654f, movingObj.position.y, movingObj.position.z);
        }





    }

    void OnMouseDrag()

    {

        float planeY = 2;
        movingObj = transform;

        Plane plane = new Plane(Vector3.up, Vector3.up * planeY); // ground plane

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        float distance; // the distance from the ray origin to the ray intersection of the plane
        if (plane.Raycast(ray, out distance))
        {
            movingObj.position = ray.GetPoint(distance); // distance along the ray
        }

    }

}

/*Code auzug aus der Quelle: https://forum.unity.com/threads/solved-moving-gameobject-along-x-and-z-axis-by-drag-and-drop-using-x-and-y-from-screenspace.488476/ */
