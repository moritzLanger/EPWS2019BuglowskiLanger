﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class ZufallOberklasse : MonoBehaviour
{

    protected System.Random random = new System.Random();
    protected GameObject temp;
    protected Text texte;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void ZufallsgeneratorMethode(int[] zufallsarray, int anzahl)
    {
        int i = 0;
        while (i < anzahl)
        {
            bool pruefung = true;
            int temp2 = random.Next(1, 10);
            for (int j = 0; j < anzahl; j++)
            {
                if (zufallsarray[j] == temp2)
                {
                    pruefung = false;
                }
            }
            if (pruefung)
            {
                zufallsarray[i] = temp2;
                i++;
            }
        }
    }

}

