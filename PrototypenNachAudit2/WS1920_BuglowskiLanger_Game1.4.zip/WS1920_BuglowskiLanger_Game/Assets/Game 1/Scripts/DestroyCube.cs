﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyCube : MonoBehaviour
{

    public GameObject tubetrigObj;
    public Material correctMat, falseMat, resetMat;
    //GameObject farbe;
    TriggerTube trigscript;
    private bool korrekt = false;
    public int destroyedCubes = 0;

    private void Update()
    {
        
    }

    private void Start()
    {
        
    }
    private void OnTriggerStay(Collider other)
    {
        
        if (trigscript.tubeZahl == other.GetComponent<ZahlSpiel1>().summe && !trigscript.prueft)
        {
            Destroy(other.gameObject);
            destroyedCubes++;
            korrekt = false;
        }
        else if (!trigscript.prueft)
        {
            ZahlSpiel1 cs = other.gameObject.GetComponent<ZahlSpiel1>();
            other.transform.position = cs.startPosi;
            korrekt = false;
        }

    }

    private void OnTriggerEnter(Collider other)
    {
        trigscript = tubetrigObj.GetComponent<TriggerTube>();
        if(trigscript.tubeZahl == other.GetComponent<ZahlSpiel1>().summe)
        {
            korrekt = true;
        }
    }


    private void OnTriggerExit(Collider other)
    {
        /*
        if (trigscript.farbe.material.color == correctMat.color)
        {
            Destroy(other.gameObject);
            trigscript.prueft = false;
        }
        else if (trigscript.farbe.material.color == falseMat.color)
        {
            Zahl cs = other.gameObject.GetComponent<Zahl>();
            other.transform.position = cs.startPosi;
            trigscript.prueft = false;

        }*/
        //Debug.Log("Exit " + other.name);
        //farbe.material = resetMat;
    }
}




/*
 * 
 * private void OnTriggerEnter(Collider other)
    {
        trigscript = tubetrigObj.GetComponent<TriggerTube>();
        //Debug.Log("farbe  " + tube.name);
        Debug.Log("Berührt " + other.name );
        //farbe.material = resetMat;
        Debug.Log("Farbe Tube " + trigscript.farbe.material.color);
        Debug.Log("Farbe Mat " + correctMat.color);
        if (trigscript.farbe.material.color == correctMat.color)
        {
            Destroy(other.gameObject);
            trigscript.prueft = false;
        }
        else if(trigscript.farbe.material.color == falseMat.color)
        {
           Zahl cs = other.gameObject.GetComponent<Zahl>();
            other.transform.position = cs.startPosi;
            trigscript.prueft = false;

        }
        Debug.Log("prüft er " + trigscript.prueft);
        
        //farbe.material.color = resetMat.color;
        trigscript.farbe.material = falseMat;
        
    }
*/