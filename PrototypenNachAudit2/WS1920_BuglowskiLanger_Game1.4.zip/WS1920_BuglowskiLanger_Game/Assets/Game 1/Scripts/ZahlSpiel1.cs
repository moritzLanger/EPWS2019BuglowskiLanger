﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ZahlSpiel1 : MonoBehaviour
{
    GameObject textObj;
    public Text changeText;
    public int zahl1, zahl2, summe;
    public Vector3 startPosi;
    // Start is called before the first frame update
    void Start()
    {
        startPosi = this.gameObject.transform.position;
       
        summe = zahl1 + zahl2;
     
        changeText.text = zahl1 + "+" + zahl2;
        
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
