﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zahl : MonoBehaviour
{
    private int wertigkeit;

    public void setWertigkeit(int neu)
    {
        wertigkeit = neu;
    }
    public int getWertigkeit()
    {
        return wertigkeit;
    }
}
