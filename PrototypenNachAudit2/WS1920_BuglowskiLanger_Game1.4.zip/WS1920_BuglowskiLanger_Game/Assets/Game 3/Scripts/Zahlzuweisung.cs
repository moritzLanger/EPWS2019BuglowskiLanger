﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Zahlzuweisung : MonoBehaviour
{/*
    GameObject b1, b2, b3, b4, b5, b6;
    List<int> zahlen = new List<int>();
    
    
    // Start is called before the first frame update
    void Start()
    {
        for(int i = 0; i < 6; i++)
        {
            zahlen.Add(i);
        }
        for (int i = 0; i < 6; i++)
        {
            //GameObject block = GameObject.Find("Zahlenblock"+(i+1));
            //Text t = block.GetComponent<Text>();
            //int zahl = (int)Random.Range(0, zahlen.Count);
            //print(zahl);

            //block.GetComponent<Text>().text = ;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }*/
}
