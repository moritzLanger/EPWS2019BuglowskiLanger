﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class controlscript : MonoBehaviour
{
    public GameObject trigger;
    private int counter = 0;
    public bool allerichtig = false;

    public void  test ()
    {
        counter = 0;
        for (int i = 1; i < 7; i++) {

            trigger = GameObject.Find("Trigger "+ i);
            if (trigger.GetComponent<Triggerscript>().count == 1)
            {
                counter++;
            }          
        }
        if (counter == 6)
        {
            allerichtig = true;
            print("alle Würfel an der Richtigen position");
        }
    }
    public void negativtest()
    {
        counter = 6;
        for (int i = 1; i < 7; i++)
        {

            trigger = GameObject.Find("Trigger " + i);
            if (trigger.GetComponent<Triggerscript>().count == 0)
            {
                counter--;
            }
        }
        if (counter != 6)
        {
            allerichtig = false;
            print("alle Würfel NICHT an der Richtigen position");
        }
    }
}
