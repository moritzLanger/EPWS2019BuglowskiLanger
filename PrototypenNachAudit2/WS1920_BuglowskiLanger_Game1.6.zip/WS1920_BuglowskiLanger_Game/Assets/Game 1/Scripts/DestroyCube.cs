﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyCube : MonoBehaviour
{

    public GameObject tubetrigObj;
    public Material correctMat, falseMat, resetMat;
    //GameObject farbe;
    TriggerTube trigscript;
    public int destroyedCubes = 0;

    private void OnTriggerStay(Collider other)
    {

        if (trigscript.tubeZahl == other.GetComponent<ZahlSpiel1>().summe && !trigscript.prueft)
        {
            Destroy(other.gameObject);
            destroyedCubes++;

        }
        else if (!trigscript.prueft)
        {
            ZahlSpiel1 cs = other.gameObject.GetComponent<ZahlSpiel1>();
            other.transform.position = cs.startPosi;

        }

    }

    private void OnTriggerEnter(Collider other)
    {
        trigscript = tubetrigObj.GetComponent<TriggerTube>();

    }
}