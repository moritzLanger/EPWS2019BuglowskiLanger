﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MovementSpiel1 : MonoBehaviour

{
    Transform draggingObject;

    void OnMouseDrag()

    {

        float planeY = -22;
        draggingObject = transform;

        Plane plane = new Plane(Vector3.forward, Vector3.forward * planeY); // ground plane

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        float distance; // the distance from the ray origin to the ray intersection of the plane
        if (plane.Raycast(ray, out distance))
        {
}
            draggingObject.position = ray.GetPoint(distance); // distance along the ray
        }



   
        void Update()
        {
        //Unsichtbarer Boden
        if (draggingObject != null && draggingObject.transform.position.y < 1)
        {
            draggingObject.position = new Vector3(draggingObject.position.x, 1f, draggingObject.position.z);
        }
        else if (draggingObject != null && draggingObject.transform.position.y > 7.5)
        {
            draggingObject.position = new Vector3(draggingObject.position.x, 7.5f, draggingObject.position.z);
        }


            //Unsichtbare Wand
            if (draggingObject != null && draggingObject.transform.position.x < -8.6f)//links
                {
                draggingObject.position = new Vector3(-8.6f, draggingObject.position.y, draggingObject.position.z);
                }
            else if(draggingObject != null && draggingObject.transform.position.x > 8.6f)//rechts
                {
                draggingObject.position = new Vector3(8.6f, draggingObject.position.y, draggingObject.position.z);
                }
            



        
        }

}