﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{
    private System.Random random = new System.Random();

    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnClickSpielAuswBtn()
    {
        PlayerPrefs.SetString("gamemode", "norm");
        Debug.Log(PlayerPrefs.GetString("gamemode"));
        SceneManager.LoadScene(1);
    }

    public void OnClickGame1Btn()
    {
        SceneManager.LoadScene(2);
    }

    public void OnClickGame2Btn()
    {
        SceneManager.LoadScene(3);
    }

    public void OnClickGame3Btn()
    {
        SceneManager.LoadScene(4);
    }

    public void OnClickRndmBtn()
    {
        PlayerPrefs.SetString("gamemode", "random");
        int randomScene = random.Next(2, 5);
        SceneManager.LoadScene(randomScene);
    }

    public void ExitBtnFunk()
    {
       SceneManager.LoadScene(0);
    }
}
