﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class Zufallsgenerator : ZufallOberklasse
{
    private Vector3[] positionsarray = new Vector3[7];
    private static int anzahl = 7;
    private int[] zufallsarray = new int[anzahl];

    // Start is called before the first frame update
    void Start()
    {
        
        ZufallsgeneratorMethode(zufallsarray, anzahl);
        Array.Sort(zufallsarray);
        for (int i = 1; i < 7; i++)
        {
            temp = GameObject.Find("Cube " + i);
            positionsarray[(i - 1)] = temp.transform.position;
            texte = temp.GetComponentInChildren<Text>();
            texte.text = zufallsarray[i - 1].ToString();
        }
        Positionszufall();
    }



    public void Positionszufall()
    {
        for (int i = 1; i < 6; i++)
        {

            temp = GameObject.Find("Cube " + i);
            RandomPos(temp, i);
        }
        temp = GameObject.Find("Cube 6");
        int lauf = 0;
        while (positionsarray[lauf].Equals(leer))
        {
            lauf++;
        }
        temp.transform.position = positionsarray[lauf];
        positionsarray[lauf] = leer;

    }

    private void RandomPos(GameObject Pos, int i)
    {
        int zufallsnummer = random.Next(0, 6);

        if (positionsarray[zufallsnummer].Equals(leer))
        {
            RandomPos(Pos, i);
        }
        else
        {
            if ((i - 1) == zufallsnummer)
            {

                RandomPos(Pos, i);
            }
            else
            {
                Pos.transform.position = positionsarray[zufallsnummer];
                positionsarray[zufallsnummer] = leer;
            }
        }



    }


    /*
    Vector3[] positionen = new Vector3[anzahl];
    for (int i = 1; i < 7; i++)
    {
        temp = GameObject.Find("Cube " + i);
        i--;
        positionen[i] = temp.transform.position;    
        print(temp.transform.position);
        print(positionen[i]);
        i++;
    }
    for(int j = 1; j < 7; j++)
    {
        temp = GameObject.Find("Cube " + j);
        temp.transform.position = positionen[ZufallfuerPosi(j)];
    }
}*/
    /*
    public int ZufallfuerPosi(int i)
    {
        int posiZufall = random.Next(0, 7);
        if(posiZufall == i)
        {

            return ZufallfuerPosi(i);
        }
        return posiZufall;
    }*/

}


