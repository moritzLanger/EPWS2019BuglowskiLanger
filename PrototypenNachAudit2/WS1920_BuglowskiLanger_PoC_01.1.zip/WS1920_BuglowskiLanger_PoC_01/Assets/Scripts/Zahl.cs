﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Zahl : MonoBehaviour
{
    GameObject textObj;
    public Text changeText;
    public int zahl1, zahl2, summe;
    public Vector3 startPosi;
    // Start is called before the first frame update
    void Start()
    {
        startPosi = this.gameObject.transform.position;
        //zahl1 = 1;
        //zahl2 = 2;
        summe = zahl1 + zahl2;
        //textObj = GameObject.Find("Text");
        //changeText = textObj.GetComponent<Text>();
        if (this.gameObject.name.StartsWith("TriggerTube"))
        {
            changeText.text = summe.ToString();
        }
        else
        {
        changeText.text = zahl1 + "+" + zahl2;
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
