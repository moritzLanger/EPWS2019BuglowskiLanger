﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerTube : MonoBehaviour
{
    public GameObject tube;
    public Material correctMat,falseMat,resetMat;
    GameObject cube,tubeTr;
    Zahl cs;
    private int tubeZahl;
    Renderer farbe;

    private void OnTriggerEnter(Collider other)
    {
        cube = other.gameObject;
        cs = cube.GetComponent<Zahl>();
        tubeTr = this.gameObject;
        //tube = GameObject.Find("TubeEP");
        farbe = tube.GetComponent<Renderer>();
        if (farbe.material.color != Color.green) {
         if(cs.summe == tubeZahl)
            {
                farbe.material = correctMat;
                // Destroy(other.gameObject);






            }
            else
            {
                farbe.material = falseMat;
                //cube.transform.SetPositionAndRotation(new Vector3(1.28f, 3.42f, -21.96f), new Quaternion());
                cube.transform.position = cs.startPosi;
            }
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (cs.summe != tubeZahl)
        {
            farbe.material = falseMat;
            cube.transform.position = cs.startPosi;

        }
        else
        {
            other.GetComponent<Rigidbody>().useGravity = false;
            other.transform.position = Vector3.MoveTowards(other.transform.position, new Vector3(tube.transform.position.x, tube.transform.position.y, other.transform.position.z), Time.deltaTime * 50f);
            other.transform.position = Vector3.MoveTowards(other.transform.position, new Vector3(tube.transform.position.x, tube.transform.position.y, 13f), Time.deltaTime * 15);


           
        }

    }
    public void settubeZahl(int neu)
    {
        tubeZahl = neu;
    }
    private void OnTriggerExit(Collider other)
    {
        if (cs.summe == tubeZahl)
        {
            Destroy(other.gameObject);

        }
        farbe.material = resetMat; 
        
    }

   
}