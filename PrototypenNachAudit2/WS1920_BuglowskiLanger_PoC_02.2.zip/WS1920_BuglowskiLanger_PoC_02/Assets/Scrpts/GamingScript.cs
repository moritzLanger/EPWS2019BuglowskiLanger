﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GamingScript : MonoBehaviour
{
    public int anzPlates = 2;
    public int count = 0;
    public GameObject complete;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void Update()
    {
        CheckPlates();
    }

    // Update is called once per frame
    private  void CheckPlates()
    {
        count = 0;
        for (int i = 1; i < anzPlates + 1; i++)
        {
            if (GameObject.Find("Numberplate " + i).GetComponentInChildren<Triggerplate>().ausgefuellt)
            {
                count++;
            }
        }
        if (count == anzPlates)
        {
            complete.SetActive(true);
            
            Application.Quit();
        }

    }

    public void Exitbutton()
    {
        complete.SetActive(true);
    }
}
