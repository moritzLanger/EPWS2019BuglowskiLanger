﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Movement : MonoBehaviour
{

    Transform draggingObject;
   

    void Update()
    {
        //Unsichtbarer Boden
        if (draggingObject != null && draggingObject.transform.position.y < 1.25)//Boden
        {
            draggingObject.position = new Vector3(draggingObject.position.x, 1.25f, draggingObject.position.z);
        }
        else if (draggingObject != null && draggingObject.transform.position.x < -22.48654 && draggingObject.transform.position.z > 47.5)//Links Hinten
        {
            draggingObject.position = new Vector3(-22.48654f, draggingObject.position.y, 47.5f);
        }
        else if (draggingObject != null && draggingObject.transform.position.x < -22.48654 && draggingObject.transform.position.z < 1.28891f)//Links Vorne
        {
            draggingObject.position = new Vector3(-22.48654f, draggingObject.position.y, 1.28891f);
        }else if (draggingObject != null && draggingObject.transform.position.x > 22.48654 && draggingObject.transform.position.z > 47.5)//Rechts Hinten
        {
            draggingObject.position = new Vector3(22.48654f, draggingObject.position.y, 47.5f);
        }
        else if (draggingObject != null && draggingObject.transform.position.x > 22.48654 && draggingObject.transform.position.z < 1.28891f)//Rechts Vorne
        {
            draggingObject.position = new Vector3(22.48654f, draggingObject.position.y, 1.28891f);
        }
        else if (draggingObject != null && draggingObject.transform.position.z > 47.5)//Hinten
        {
            draggingObject.position = new Vector3(draggingObject.position.x, draggingObject.position.y, 47.5f);
        }
        else if (draggingObject != null && draggingObject.transform.position.z < 1.28891f)//Vorne
        {
            draggingObject.position = new Vector3(draggingObject.position.x, draggingObject.position.y, 1.28891f);
        }
        else if (draggingObject != null && draggingObject.transform.position.y > 15)//Höhe
        {
            draggingObject.position = new Vector3(draggingObject.position.x,15f ,draggingObject.position.z);
        }else if (draggingObject != null && draggingObject.transform.position.x < -22.48654)//Links
        {
            draggingObject.position = new Vector3(-22.48654f, draggingObject.position.y, draggingObject.position.z);
        }
        else if (draggingObject != null && draggingObject.transform.position.x > 22.48654)//Links
        {
            draggingObject.position = new Vector3(22.48654f, draggingObject.position.y, draggingObject.position.z);
        }





    }

    void OnMouseDrag()

    {

        float planeY = 2;
        draggingObject = transform;

        Plane plane = new Plane(Vector3.up, Vector3.up * planeY); // ground plane

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        float distance; // the distance from the ray origin to the ray intersection of the plane
        if (plane.Raycast(ray, out distance))
        {
            draggingObject.position = ray.GetPoint(distance); // distance along the ray
        }

    }

}

/*Code auzug aus der Quelle: https://forum.unity.com/threads/solved-moving-gameobject-along-x-and-z-axis-by-drag-and-drop-using-x-and-y-from-screenspace.488476/ */
