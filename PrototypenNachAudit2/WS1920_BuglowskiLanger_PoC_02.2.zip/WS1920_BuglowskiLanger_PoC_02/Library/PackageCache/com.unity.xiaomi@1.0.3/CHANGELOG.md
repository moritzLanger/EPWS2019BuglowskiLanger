# Changelog
## [1.0.3] - 2018-07-25
-  Update asmdef file to avoid building bug.

## [1.0.2] - 2018-03-23
- Add Unity version to package.json.

## [1.0.1] - 2018-03-20
- Exception instead of crash will be reported when Xiaomi's functions are run in editor.

## [1.0.0] - 2017-06-20
### Added
- First release of Xiaomi package.