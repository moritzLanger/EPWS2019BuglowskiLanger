﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class Zufallsgenerator : MonoBehaviour
{
    static int anzahl = 6;
    int [] zufallsarray = new int[anzahl];
    public  System.Random random = new System.Random();
    public GameObject temp;
    public Text texte;

    // Start is called before the first frame update
    void Start()
    {
        ZufallsgeneratorMethode();
        for(int i = 1; i < 7; i++)
        {
        temp = GameObject.Find("Cube " + i );
        texte = temp.GetComponentInChildren<Text>();
        texte.text =  zufallsarray[i-1].ToString();
        }
    }
    

    public void ZufallsgeneratorMethode()
    {
        int i = 0;
        while(i < 6){    
            bool pruefung = true;
            int temp2 = random.Next(0, 10);
            for(int j = 0; j <6; j++){
                if (zufallsarray[j] == temp2){
                    pruefung = false;
                }
            }
            if(pruefung){
            zufallsarray[i]  = temp2;
            print(zufallsarray[i]);
            i++;
            }
        }

        
        Array.Sort(zufallsarray);
    }
    public void Positionszufall(){
        
    }
}


