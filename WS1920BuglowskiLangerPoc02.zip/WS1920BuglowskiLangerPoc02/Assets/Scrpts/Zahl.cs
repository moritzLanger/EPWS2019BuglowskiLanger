﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zahl : MonoBehaviour
{
    public int wertigkeit;

}
