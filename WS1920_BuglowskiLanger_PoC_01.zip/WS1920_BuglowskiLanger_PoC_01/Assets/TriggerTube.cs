﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerTube : MonoBehaviour
{

    // Destroy everything that enters the trigger
    void OnTriggerEnter(Collider other)
    {
        GameObject cube = other.gameObject;
        Zahl cs = cube.GetComponent<Zahl>();
        GameObject tubeTr = this.gameObject;
        Zahl ts = tubeTr.GetComponent<Zahl>();
        GameObject tube = GameObject.Find("TubeEP");
        var farbe = tube.GetComponent<Renderer>();
        if(farbe.material.color != Color.green) {
         if(cs.summe == ts.summe)
            {
                farbe.material.SetColor("_Color", Color.green);
                Destroy(other.gameObject);
            
            }
            else
            {
                farbe.material.SetColor("_Color", Color.red);
                cube.transform.SetPositionAndRotation(new Vector3(1.28f, 3.42f, -21.96f), new Quaternion());
                //cube.transform.position = new Vector3(-2.53f, 12.4f, -21.96f);
            }
        }
          


        //Destroy(other.gameObject);
    }
}