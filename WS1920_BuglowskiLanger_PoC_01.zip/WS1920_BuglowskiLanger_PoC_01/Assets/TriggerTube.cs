﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerTube : MonoBehaviour
{

    // Destroy everything that enters the trigger
    void OnTriggerEnter(Collider other)
    {
        GameObject cube = other.gameObject;
        Zahl cs = cube.GetComponent<Zahl>();
        GameObject tube = this.gameObject;
        Zahl ts = tube.GetComponent<Zahl>();
        var farbe = tube.GetComponent<Renderer>();
        if(cs.summe == ts.summe)
        {
            farbe.material.SetColor("_Color", Color.green);
            Destroy(other.gameObject);
            
        }
        else
        {
            farbe.material.SetColor("_Color", Color.red);
            cube.transform.position = new Vector3(-2.53f, 12.4f, -21.96f);
        }


        //Destroy(other.gameObject);
    }
}