﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class zahlen : MonoBehaviour
{
   public Text instru;
       public int a, b;
    public string test;
    // Start is called before the first frame update
    void Start()
    {
       
        instru = gameObject.GetComponent<Text>();

    }

    // Update is called once per frame
    void Update()
    {
        instru.text = (a.ToString() + "+"  + b.ToString());
    }
}
