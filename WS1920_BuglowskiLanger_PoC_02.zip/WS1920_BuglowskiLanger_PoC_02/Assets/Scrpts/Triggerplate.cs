﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Triggerplate : MonoBehaviour
{
    private int count = 0;
    public Boolean ausgefuellt = false;

    //Texteinfuegen texteinfuegen;
    Renderer render;
    Color DefaultColor;
    public int ueber;

    private void Start()
    {
        // GameObject number = this.gameObject;
        // texteinfuegen = number.GetComponent<Texteinfuegen>();
        // print(texteinfuegen.bodennummer);
        // ueber = texteinfuegen.bodennummer;
        // print(ueber);

        render = GetComponent<Renderer>();

        DefaultColor = render.material.color;

    }

    private void ueberpruefung()
    {
        if (count == ueber)
        {
            render.material.color = Color.green;
            ausgefuellt = true;
        }
        else
        {
            render.material.color = DefaultColor;
            ausgefuellt = false;
        }
    }
   
    private void OnTriggerEnter(Collider other)
    {
        GameObject cube = other.gameObject;
        Zahl wert = cube.GetComponent<Zahl>();
                
        count += wert.wertigkeit;
        ueberpruefung();
    }

  

    private void OnTriggerExit(Collider other)
    {
        GameObject cube = other.gameObject;
        Zahl wert = cube.GetComponent<Zahl>();

        count -= wert.wertigkeit;
        ueberpruefung();
  
    }

}
    
