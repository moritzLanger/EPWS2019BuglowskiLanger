﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Selection : MonoBehaviour
{
    public Material selectMat;
    public Material defaultMat;
    public int zaehler = 0;
    public bool fertig = false;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        while (!fertig)
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (zaehler < 2)
                {
                    var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    RaycastHit hitInfo;
                    if (Physics.Raycast(ray, out hitInfo))
                    {
                        var rig = hitInfo.collider.GetComponent<Rigidbody>();
                        if (rig != null && rig.gameObject.tag != "Selected")
                        {
                            zaehler++;
                            rig.GetComponent<MeshRenderer>().material = selectMat;
                            if (zaehler == 1)
                            {
                                rig.gameObject.tag = "Selected";
                            }
                            else if (zaehler == 2)
                            {
                                GameObject block1 = GameObject.FindWithTag("Selected");
                                Vector3 b1posi = block1.gameObject.transform.position;
                                Vector3 b2posi = rig.gameObject.transform.position;
                                block1.transform.position = b2posi;
                                rig.gameObject.transform.position = b1posi;
                                block1.GetComponent<MeshRenderer>().material = defaultMat;
                                rig.GetComponent<MeshRenderer>().material = defaultMat;
                                block1.gameObject.tag = "Untagged";
                                zaehler = 0;

                            }
                        }
                    }
                }

            }

        }
    }
}
